import React from 'react'
import "./Client.css";
function ShowDetail(){
    return(
        <div className="loader center">
            <i className="fa fa-cog fa-spin"/>
        </div>
    );
}
export default ShowDetail;